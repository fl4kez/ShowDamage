﻿using Microsoft.Xna.Framework;
using ShowDamage.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.UI;

namespace ShowDamage
{
    public class ShowDamageSystem : ModSystem
    {
        public static DamageViewCanvas DamageView;
        private UserInterface _damageView;

        public static ModKeybind toggleUI;
        int timer = -1;
        public override void Load()
        {
            if (!Main.dedServ)
            {
                DamageView = new DamageViewCanvas();
                DamageView.Activate();
                _damageView = new UserInterface();
                _damageView.SetState(DamageView);
            }
            toggleUI = KeybindLoader.RegisterKeybind(Mod, "Toggle UI", "L");
        }
        private GameTime _lastUpdateUiGameTime;
        public void ToggleUI()
        {
            if (DamageViewCanvas.isVisible)
            {
                _damageView?.SetState(null);
                DamageViewCanvas.isVisible = false;
            }
            else
            {
                _damageView?.SetState(DamageView);
                DamageViewCanvas.isVisible = true;
            }
        }
        public override void UpdateUI(GameTime gameTime)/* tModPorter Note: Removed. Use ModSystem.UpdateUI */
        {
            _lastUpdateUiGameTime = gameTime;
            if (_damageView?.CurrentState != null)
            {
                _damageView.Update(gameTime);
            }
        }
        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)/* tModPorter Note: Removed. Use ModSystem.ModifyInterfaceLayers */
        {
            int mouseTextIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Mouse Text"));
            if (mouseTextIndex != -1)
            {
                layers.Insert(mouseTextIndex, new LegacyGameInterfaceLayer(
                    "ShowDamage: DPS per source",
                    delegate
                    {
                        //_damageView.Update(Main._drawInterfaceGameTime);
                        _damageView.Draw(Main.spriteBatch, _lastUpdateUiGameTime);
                        return true;
                    },
                    InterfaceScaleType.UI)
                );
            }
        }
        public override void PostUpdateTime()
        {
            base.PostUpdateTime();
            if (DamageView.hitEnemy)
            {
                DamageView.hitEnemy = false;
                timer = 600;
            }
            timer--;
            if (timer == 0)
            {
                DamageView.Reset();
                timer = -1;
            }
        }
    }
}
